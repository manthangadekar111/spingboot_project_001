package com.org.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEmployeeExApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringEmployeeExApplication.class, args);
	}

}
