
package com.org.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.demo.entity.Employee;
import com.org.demo.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	//	ADD EMPLOYEE CONTROLLER
	@PostMapping("/addemployee")
	public Employee addEmployee(Employee employee) {
		return service.saveEmployee(employee);
	}
	
	//	ADD EMPLOYEE-S CONTROLLER
	@PostMapping("/addemployees")
	public List<Employee> addEmployees(List<Employee> employee) {
		return service.saveEmployees(employee);
	}
	
	//  GET EMPLOYEES CONTROLLER
	@GetMapping("/employees")
	public List<Employee> findAllEmployees() {
		return service.getEmployees();
		
	}
	
	//  GET EMPLOYEE BY ID CONTROLLER
	@GetMapping("/employee/{id}")
	public Optional<Employee> findEmployeeById(@PathVariable int id) {
		return service.getEmployeebyId(id);
	}
	
	//  GET EMPLOYEE BY NAME CONTROLLER
	@GetMapping("/employee/{name}")
	public Employee findEmployeeByName(@PathVariable String name) {
		return service.getEmployeeByName(name);
	}
	
	//  UPDATE EMPLOYEE CONTROLLER
	@PutMapping("/update")
	public Employee updateEmployee(Employee employee) {
		return service.updateEmployee(employee);
	}
	
	//  DELETE EMPLOYEE CONTROLLER
	@DeleteMapping("/delete/{id}")
	public String deleteEmployee(int id) {
		return service.deleteEmployeeById(id);
	}
}
