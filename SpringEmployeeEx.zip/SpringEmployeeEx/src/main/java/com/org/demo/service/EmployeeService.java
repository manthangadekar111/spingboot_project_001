package com.org.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.demo.entity.Employee;
import com.org.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	// SAVE EMPLOYEE
	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	
	// SAVE EMPLOYEES
	public List<Employee> saveEmployees(List<Employee> employees) {
		return employeeRepository.saveAll(employees);
	}
	
	// GET EMPLOYEES
	public List<Employee> getEmployees(){
		return employeeRepository.findAll();
	}
	
	// GET EMPLOYEE BY ID
	public Optional<Employee> getEmployeebyId(int id) {
		return employeeRepository.findById(id);
	}
	
	// GET EMPLOYEE BY NAME
	public Employee getEmployeeByName(String name) {
		return employeeRepository.findByName(name);
	}
	
	// DELETE EMPLOYEE BY ID
	public String deleteEmployeeById(int id) {
		employeeRepository.deleteById(id);
		return "DELETE EMPLOYEE !" + id;
	}
	
	// UPDATE EMPLOYEE
	public Employee updateEmployee(Employee employee) {
		Employee existingemployee = employeeRepository.findById(employee.getId()).orElse(null);
		existingemployee.setName(employee.getName());
		existingemployee.setAddress(employee.getAddress());
		existingemployee.setEmail(employee.getEmail());
		return employeeRepository.save(existingemployee);
	}
}
