package com.org.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEmployeeExApplicationTests {

	@Test
	void contextLoads() {
	}

}
